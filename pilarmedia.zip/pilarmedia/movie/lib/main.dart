import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'Page/splash.dart';

import 'dependency_injection.dart';

void main() {
  runApp(MainApp());
  DependencyInjection.init();
}

class MainApp extends StatelessWidget {
  // final InternetConnectionController _internetController =
  //     Get.put(InternetConnectionController());

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      home: splash(),
    );
  }
}
