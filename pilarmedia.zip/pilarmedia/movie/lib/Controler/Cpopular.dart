import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../Model/popular.dart'; // Ganti dengan nama proyek dan path model yang sesuai

class PopularController extends GetxController {
  var isLoading = true.obs;
  var movies = <Result>[].obs;

  @override
  void onInit() {
    fetchPopularMovies();
    super.onInit();
  }

  void fetchPopularMovies() async {
    try {
      isLoading(true);

      final apiKey = "fbb9572d11b5458ac98f02b84f2bafc4";
      final baseUrl = "https://api.themoviedb.org/3/movie/popular";
      final url = "$baseUrl?api_key=$apiKey";

      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final jsonBody = json.decode(response.body);
        final popularModel = Popular.fromJson(jsonBody);

        movies.assignAll(popularModel.results);
      } else {
        // Handle API error
        print("Error: ${response.statusCode}");
      }
    } catch (e) {
      // Handle other errors
      print("Error: $e");
    } finally {
      isLoading(false);
    }
  }
}
