// movie_controller.dart

import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../Model/detail.dart';

class MovieController extends GetxController {
  final String apiKey = "fbb9572d11b5458ac98f02b84f2bafc4";
  final String baseUrl = "https://api.themoviedb.org/3/movie";

  Rx<Detail?> movieDetail = Rx<Detail?>(null);

  Future<void> getMovieDetail(int id) async {
    try {
      String url = "$baseUrl/$id?api_key=$apiKey";
      var response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        var jsonResponse = json.decode(response.body);
        movieDetail.value = Detail.fromJson(jsonResponse);
      } else {
        movieDetail.value = null;
        print("Request failed with status: ${response.statusCode}.");
      }
    } catch (e) {
      movieDetail.value = null;
      print("Error occurred: $e");
    }
  }
}
