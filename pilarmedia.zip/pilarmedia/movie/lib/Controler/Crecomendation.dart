import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

// Model classes
import '../Model/recomendation.dart';

class CrekomendasiController extends GetxController {
  final String baseUrl = 'https://api.themoviedb.org/3';
  final String apiKey = 'fbb9572d11b5458ac98f02b84f2bafc4';

  var isLoading = false.obs;
  var recommendedMovies = List<Result>.empty().obs;

  Future<void> getMovieRecommendations(int movieId) async {
    try {
      isLoading(true);

      final response = await http.get(
        Uri.parse('$baseUrl/movie/$movieId/recommendations?api_key=$apiKey'),
      );

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final List<dynamic> resultsData = jsonData['results'];

        recommendedMovies.value = resultsData
            .map((resultJson) => Result.fromJson(resultJson))
            .toList();
      } else {
        // Tangani respon error
        print('Error: ${response.statusCode}');
      }
    } catch (e) {
      // Tangani eksepsi
      print('Exception: $e');
    } finally {
      isLoading(false);
    }
  }
}
