import 'package:get/get.dart';
import '../Model/nowaplaying.dart';
import 'package:http/http.dart' as http;

class NowPlayingControler extends GetxController {
  RxList<Result> nowPlayingData = <Result>[].obs;

  @override
  void onInit() {
    super.onInit();
    fetchData();
  }

  void fetchData() async {
    final url =
        "https://api.themoviedb.org/3/movie/now_playing?api_key=fbb9572d11b5458ac98f02b84f2bafc4";

    try {
      final response = await http.get(Uri.parse(url));

      print('Response status code: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 200) {
        final nowPlaying = nowPlayingFromJson(response.body);

        nowPlayingData.assignAll(nowPlaying.results);
        //print("INI AMAN");
      } else {
        print('Request gagal dengan status code: ${response.statusCode}');
      }
    } catch (error) {
      print('Error saat melakukan request: $error');
    }
  }
}
