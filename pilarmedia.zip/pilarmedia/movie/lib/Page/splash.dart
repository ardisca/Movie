import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:movie/Page/home_page.dart';

class splash extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: AnimatedSplashScreen(
            duration: 3000,
            splash: Lottie.network(
                "https://lottie.host/50ebee20-228d-4888-98e2-8e0ac49d02d7/08HGrnZ6YV.json",
                height: double.infinity,
                width: double.infinity),
            nextScreen: home_page(),
            backgroundColor: Colors.white),
      ),
    );
  }
}
