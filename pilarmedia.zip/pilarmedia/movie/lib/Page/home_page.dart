import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:movie/Controler/CnowPlaying.dart';
import 'package:movie/Page/detail_page.dart';
import 'package:movie/Page/list_page.dart';

import '../Controler/Cpopular.dart';

class home_page extends StatelessWidget {
  final NowPlayingControler controler = Get.put(NowPlayingControler());
  final popularController = Get.put(PopularController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Center(
                    child: Text(
                      "Movies",
                      style:
                          TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                SizedBox(
                  height: 8,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    onSubmitted: (value) {
                      Get.to(List_page(
                        kunci: value,
                      ));
                    },
                    textInputAction: TextInputAction.search,
                    decoration: InputDecoration(
                      prefixIcon: Icon(Icons.search),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(width: 3),
                        borderRadius: BorderRadius.circular(50.0),
                      ),
                      hintText: 'Search Movie',
                    ),
                  ),
                ),
                SizedBox(
                  height: 12,
                ),
                Text(
                  "Now Playing",
                  style: TextStyle(fontSize: 22.5, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  height: 8,
                ),
                Container(
                  padding: EdgeInsets.all(8),
                  height: 225,
                  //color: Colors.amber,
                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      return Obx(() {
                        if (controler.nowPlayingData.isEmpty) {
                          return Center(
                            child: CircularProgressIndicator(),
                          );
                        } else {
                          return ListView.builder(
                              scrollDirection: Axis.horizontal,
                              itemCount: controler.nowPlayingData.length,
                              itemBuilder: (context, index) {
                                final movieNewPLay =
                                    controler.nowPlayingData[index];
                                return Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: InkWell(
                                    onTap: () {
                                      //movieNewPLay.id;
                                      Get.to(detail_page(
                                        id: movieNewPLay.id,
                                      ));
                                    },
                                    child: Container(
                                      width: 100,
                                      height: constraints.maxHeight,
                                      child: Column(
                                        children: [
                                          Expanded(
                                            child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                child: Stack(
                                                  children: [
                                                    Container(
                                                      color: Colors
                                                          .black, // Warna hitam sebagai placeholder
                                                      width: double.infinity,
                                                      height: double.infinity,
                                                    ),
                                                    Image.network(
                                                      "https://image.tmdb.org/t/p/w500/${movieNewPLay.posterPath}",
                                                      fit: BoxFit.cover,
                                                      width: double.infinity,
                                                      height: double.infinity,
                                                    ),
                                                  ],
                                                )),
                                          ),
                                          SizedBox(height: 5),
                                          Text(movieNewPLay.title, maxLines: 1),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              });
                        }
                      });
                    },
                  ),
                ),
                SizedBox(
                  height: 12,
                ),
                SizedBox(
                  height: 12,
                ),
                Text(
                  "Popular",
                  style: TextStyle(fontSize: 22.5, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  height: 8,
                ),
                Obx(() {
                  if (popularController.isLoading.value) {
                    return Center(
                      child: CircularProgressIndicator(),
                    );
                  } else {
                    return Column(
                      children: [
                        ListView.builder(
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: popularController.movies.length,
                            itemBuilder: (context, index) {
                              final movie = popularController.movies[index];
                              return Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: InkWell(
                                  onTap: () {
                                    Get.to(detail_page(id: movie.id));
                                  },
                                  child: Container(
                                    height: 150,
                                    width: double.infinity,
                                    decoration: BoxDecoration(
                                        color: Colors.amber,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(20))),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20),
                                      child: Row(children: [
                                        Container(
                                          decoration: BoxDecoration(
                                              color: Colors.black),
                                          child: Image(
                                              image: NetworkImage(
                                                  "https://image.tmdb.org/t/p/w500/${movie.posterPath}"),
                                              fit: BoxFit.cover),
                                        ),
                                        Flexible(
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text("${movie.title}",
                                                    maxLines: 2,
                                                    softWrap: true,
                                                    textAlign: TextAlign.left,
                                                    style: TextStyle(
                                                      fontSize: 20,
                                                    )),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Text(
                                                    "Popularity    : ${movie.popularity}"),
                                                SizedBox(
                                                  height: 2.5,
                                                ),
                                                Text(
                                                    "Vote Average  : ${movie.voteAverage}"),
                                              ],
                                            ),
                                          ),
                                        )
                                      ]),
                                    ),
                                  ),
                                ),
                              );
                            })
                      ],
                    );
                  }
                })
              ],
            ),
          ),
        ),
      ),
    );
  }
}
