import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:movie/Page/detail_page.dart';
import '../Controler/Csearch.dart';

class List_page extends StatelessWidget {
  //var kunci;

  List_page({required this.kunci});
  String kunci;
  final searchCon = Get.put(SearchC());
  @override
  Widget build(BuildContext context) {
    searchCon.performSearch(kunci);
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Center(
                  child: Text(
                    "Movies",
                    style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              Expanded(child: Obx(() {
                if (searchCon.isLoading.value) {
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                } else {
                  if (searchCon.searchResults.isEmpty) {
                    // Menampilkan pesan "Data tidak ditemukan" jika hasil pencarian kosong
                    return Center(
                      child: Text(
                        "Data tidak ditemukan",
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                    );
                  } else {
                    return ListView.builder(
                        itemCount: searchCon.searchResults.length,
                        itemBuilder: (context, index) {
                          final movie = searchCon.searchResults[index];
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: InkWell(
                              onTap: () {
                                Get.to(detail_page(
                                  id: movie.id,
                                ));
                              },
                              child: Container(
                                height: 150,
                                width: double.infinity,
                                decoration: BoxDecoration(
                                    color: Colors.amber,
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(20))),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(20),
                                  child: Row(children: [
                                    Image(
                                        image: NetworkImage(
                                            "https://image.tmdb.org/t/p/w500/${movie.posterPath}"),
                                        fit: BoxFit.cover),
                                    Flexible(
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text("${movie.title}",
                                                softWrap: true,
                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                  fontSize: 20,
                                                )),
                                            SizedBox(
                                              height: 5,
                                            ),
                                            Text(
                                                "Popularity    : ${movie.popularity}"),
                                            SizedBox(
                                              height: 2.5,
                                            ),
                                            Text(
                                                "Vote Average  : ${movie.voteAverage}"),
                                          ],
                                        ),
                                      ),
                                    )
                                  ]),
                                ),
                              ),
                            ),
                          );
                        });
                  }
                }
              })),
            ],
          ),
        ),
      ),
    );
  }
}
