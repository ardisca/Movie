import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../Controler/Cdetail.dart';
import '../Controler/Crecomendation.dart';
import '../Model/detail.dart';

class detail_page extends StatelessWidget {
  detail_page({required this.id});
  int id;
  @override
  Widget build(BuildContext context) {
    final MovieController controler = Get.put(MovieController());
    final CrekomendasiController controllerRecomendation =
        Get.put(CrekomendasiController());
    controllerRecomendation.getMovieRecommendations(id);
    // Fetch movie detail when the page is loaded
    WidgetsBinding.instance?.addPostFrameCallback((_) {
      controler.getMovieDetail(id);
    });

    return Scaffold(
      body: SafeArea(child: SingleChildScrollView(
        child: Obx(() {
          if (controler.movieDetail.value == null) {
            return Center(
              child: CircularProgressIndicator(),
            );
          } else {
            Detail detail = controler.movieDetail.value!;
            return Column(children: [
              Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  Container(
                    height: 250,
                    width: double.infinity,
                    child: Image(
                      image: NetworkImage(
                          "https://image.tmdb.org/t/p/w500/${detail.backdropPath}"),
                      fit: BoxFit.cover,
                    ),
                  ),
                  Container(
                    height: 250,
                    width: double.infinity,
                    decoration:
                        BoxDecoration(color: Colors.black.withOpacity(0.5)),
                  ),
                  Column(
                    children: [
                      Container(
                        height: 175,
                        child: Image.network(
                          "https://image.tmdb.org/t/p/w500/${detail.posterPath}",
                          fit: BoxFit.cover,
                        ),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(
                        "${detail.title}",
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                    ],
                  )
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Container(
                      height: 100,
                      width: 100,
                      decoration: BoxDecoration(
                          color: Colors.amber,
                          borderRadius: BorderRadius.circular(20)),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.star),
                          SizedBox(
                            height: 3,
                          ),
                          Text("Vote Average"),
                          SizedBox(
                            height: 3,
                          ),
                          Text("${detail.voteAverage}"),
                        ],
                      ),
                    ),
                    Container(
                      height: 100,
                      width: 100,
                      decoration: BoxDecoration(
                          color: Colors.amber,
                          borderRadius: BorderRadius.circular(20)),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.how_to_vote),
                          SizedBox(
                            height: 3,
                          ),
                          Text("Vote Count"),
                          SizedBox(
                            height: 3,
                          ),
                          Text("${detail.voteCount}"),
                        ],
                      ),
                    ),
                    Container(
                      height: 100,
                      width: 100,
                      decoration: BoxDecoration(
                          color: Colors.amber,
                          borderRadius: BorderRadius.circular(20)),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.people),
                          SizedBox(
                            height: 3,
                          ),
                          Text("Popularity"),
                          SizedBox(
                            height: 3,
                          ),
                          Text("${detail.popularity}"),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 12,
              ),
              Text(
                "Deskripsi",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
              ),
              SizedBox(
                height: 8,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text("${detail.overview}"),
              ),
              SizedBox(
                height: 12,
              ),
              Text(
                "Recommendation",
                style: TextStyle(fontSize: 22.5, fontWeight: FontWeight.bold),
              ),
              SizedBox(
                height: 8,
              ),
              Obx(() {
                if (controllerRecomendation.isLoading.value) {
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                } else if (controllerRecomendation.recommendedMovies.isEmpty) {
                  return Center(
                    child: Text('Tidak ada film rekomendasi.'),
                  );
                } else {
                  return Container(
                    padding: EdgeInsets.all(8),
                    height: 225,
                    //color: Colors.amber,
                    child: LayoutBuilder(
                      builder: (context, constraints) {
                        return ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: controllerRecomendation
                                .recommendedMovies.length,
                            itemBuilder: (context, index) {
                              final recomendationMov = controllerRecomendation
                                  .recommendedMovies[index];
                              return Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: InkWell(
                                  onTap: () {
                                    int selectedId = recomendationMov.id;
                                    controler.getMovieDetail(selectedId);
                                  },
                                  child: Container(
                                    width: 100,
                                    height: constraints.maxHeight,
                                    child: Column(
                                      children: [
                                        Expanded(
                                          child: ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            child: Image.network(
                                              "https://image.tmdb.org/t/p/w500/${recomendationMov.posterPath}",
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                        SizedBox(height: 5),
                                        Text(
                                          "${recomendationMov.title}",
                                          maxLines: 1,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            });
                      },
                    ),
                  );
                }
              }),
            ]);
          }
        }),
      )),
    );
  }
}
